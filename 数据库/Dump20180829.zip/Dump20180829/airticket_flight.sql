-- MySQL dump 10.13  Distrib 8.0.11, for Win64 (x86_64)
--
-- Host: localhost    Database: airticket
-- ------------------------------------------------------
-- Server version	8.0.11

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `flight`
--

DROP TABLE IF EXISTS `flight`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `flight` (
  `FLIGHTID` int(11) NOT NULL AUTO_INCREMENT,
  `USERID` int(11) DEFAULT NULL,
  `DICID` int(11) DEFAULT NULL,
  `FLIGHTNO` varchar(20) DEFAULT NULL,
  `STARTAIRPORT` varchar(100) DEFAULT NULL,
  `ENDAIRPORT` varchar(100) DEFAULT NULL,
  `TYPE` char(1) DEFAULT NULL,
  `PLANSTARTTIME` varchar(20) DEFAULT NULL,
  `PLANENDTIME` varchar(20) DEFAULT NULL,
  `AIRRANGE` decimal(10,0) DEFAULT NULL,
  `PRICE` decimal(10,0) DEFAULT NULL,
  `FROMCITY` varchar(20) DEFAULT NULL,
  `TOCITY` varchar(20) DEFAULT NULL,
  `FLIGHTTYPE` varchar(20) DEFAULT NULL,
  `TICKETNUM` decimal(3,0) DEFAULT NULL,
  `ISSTOP` char(1) DEFAULT NULL,
  PRIMARY KEY (`FLIGHTID`),
  KEY `DICID` (`DICID`),
  KEY `USERID` (`USERID`),
  CONSTRAINT `flight_ibfk_1` FOREIGN KEY (`DICID`) REFERENCES `dirctory` (`dicid`),
  CONSTRAINT `flight_ibfk_2` FOREIGN KEY (`USERID`) REFERENCES `systemuser` (`userid`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `flight`
--

LOCK TABLES `flight` WRITE;
/*!40000 ALTER TABLE `flight` DISABLE KEYS */;
INSERT INTO `flight` VALUES (1,1,12,'CA1831','北京首都机场','上海虹桥机场','0','07:30','09:40',1088,612,'北京','上海','空客A330',335,'0'),(2,1,15,'MF8185','福州长乐机场','长沙黄花机场','0','08:20','09:30',562,336,'福州','长沙','波音737',130,'0'),(3,1,14,'CZ3821','广州白云机场','南京禄口机场','0','10:15','12:15',1121,426,'广州','南京','波音737',128,'0'),(4,1,14,'CZ6882','上海浦东机场','乌鲁木齐地窝堡机场','0','17:15','23:55',3326,1770,'上海','乌鲁木齐','波音757',148,'1'),(5,1,13,'MU5138','北京首都机场','上海虹桥机场','0','07:00','09:10',1088,1126,'北京','上海','空客A330',335,'0'),(6,1,12,'CA155','北京首都机场','上海浦东机场','0','07:35','09:35',1088,1134,'北京','上海','波音737',130,'0'),(7,1,16,'HU7603','北京首都机场','上海虹桥机场','0','21:05','23:15',1088,1132,'北京','上海','波音737',130,'0'),(8,1,15,'MF8563','福州长乐机场','上海虹桥机场','0','18:30','19:50',1029,782,'福州','上海','波音737',130,'0'),(9,1,12,'CA1856','上海虹桥机场','北京首都机场','0','20:55','23:25',1088,1135,'上海','北京','空客A330',335,'0'),(10,1,13,'T00001','上海浦东机场','福州长乐机场','0','08:20','09:50',1029,850,'上海','福州','波音747',200,'0'),(19,2,12,'T00002','北京首都机场','福州长乐机场','0','10:22','11:22',362,699,'北京','福州','波音777',100,'0'),(23,2,14,'T00003','北京首都机场','广州白云机场','0','10:11','15:33',880,998,'北京','广州','波音777',150,'1'),(24,2,14,'T00004','北京首都机场','广州白云机场','0','10:11','15:33',880,998,'北京','广州','波音777',150,'1'),(25,1,13,'T00001','上海浦东机场','福州长乐机场','0','08:20','09:50',1029,850,'上海','福州','波音777',200,'1');
/*!40000 ALTER TABLE `flight` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-08-29 18:24:06
